#!/bin/bash
commands="rosrun joy joy_node"
gnome-terminal -- bash -c "$commands" 
