#!/bin/bash

if ! pgrep -f "^/usr/bin/gnome-terminal" >/dev/null; then
	gnome-terminal &
fi
sleep 1

if [ $(pgrep -c -f "^/usr/bin/gnome-terminal") -gt 1 ]; then
	pkill -f "^/usr/bin/gnome-terminal"
fi

