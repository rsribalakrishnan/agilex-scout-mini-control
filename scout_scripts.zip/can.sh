password="12345678"

expect << EOF

spawn sudo systemctl restart networking
expect "Password for"
send "$password\r"

spawn sudo modprobe gs_usb 
expect "Password for"
send "$password\r"

spawn sudo ip link set can0 down
expect "Password for"
send "$password\r"

spawn sudo ip -details link show can0
expect "Password for"
send "$password\r"

spawn sudo ip link set can0 up type can bitrate 500000
expect "Password for"
send "$password\r"

spawn sudo ip -details link show can0
expect "Password for"
send "$password\r"

spawn sudo apt install can-utils
expect "Password for"
send "$password\r"

expect eof
EOF
