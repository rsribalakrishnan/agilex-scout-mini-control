#!/bin/bash
commands="roscore"
gnome-terminal -- bash -c "$commands"
