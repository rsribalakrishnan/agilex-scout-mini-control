#!/bin/bash
commands="cd catkin_ws; 
source devel/setup.bash;
catkin_make;
cd src;
rosrun xbox_controller scripts/scout.py"
gnome-terminal -- bash -c "$commands" 

