  GNU nano 4.8                         joy.sh                                   
#!/bin/bash
commands="cd catkin_ws; 
source devel/setup.bash;
catkin_make;
cd src;
rosrun scout_controller scripts/listener.py"
gnome-terminal -- bash -c "$commands" 

